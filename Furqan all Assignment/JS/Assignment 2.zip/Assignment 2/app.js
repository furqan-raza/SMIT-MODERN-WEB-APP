        // Third Question

var username = prompt("Enter a Name");
alert("Welcome  " + username + "!")